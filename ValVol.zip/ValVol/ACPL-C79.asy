Version 4
SymbolType BLOCK
RECTANGLE Normal 96 128 -96 -128
WINDOW 3 0 144 Center 2
WINDOW 0 0 -144 Center 2
SYMATTR Prefix X
SYMATTR SpiceModel ..\sym\ValVol\acpl-c79.lib
SYMATTR Value ACPL-C79
SYMATTR Value2 acpl-c79
SYMATTR Description Precision Miniature Isolation Amplifiers
PIN -96 -96 LEFT 8
PINATTR PinName Vdd1
PINATTR SpiceOrder 1
PIN -96 -32 LEFT 8
PINATTR PinName Vin+
PINATTR SpiceOrder 2
PIN -96 32 LEFT 8
PINATTR PinName Vin-
PINATTR SpiceOrder 3
PIN -96 96 LEFT 8
PINATTR PinName GND1
PINATTR SpiceOrder 4
PIN 96 96 RIGHT 8
PINATTR PinName GND2
PINATTR SpiceOrder 5
PIN 96 32 RIGHT 8
PINATTR PinName Vout-
PINATTR SpiceOrder 6
PIN 96 -32 RIGHT 8
PINATTR PinName Vout+
PINATTR SpiceOrder 7
PIN 96 -96 RIGHT 8
PINATTR PinName Vdd2
PINATTR SpiceOrder 8
