Version 4
SymbolType CELL
RECTANGLE Normal 96 64 -96 -64
WINDOW 3 0 -32 Center 2
WINDOW 39 0 80 Center 2
WINDOW 40 0 112 Center 2
SYMATTR Value NTC
SYMATTR SpiceLine r25=60 b25100=3991
SYMATTR SpiceLine2 tc=1.04 tau=65
SYMATTR Prefix x
SYMATTR SpiceModel NTC
SYMATTR Description NTC Thermistor
SYMATTR ModelFile ..\sym\ValVol\ntc.lib
PIN -96 -32 LEFT 8
PINATTR PinName RA
PINATTR SpiceOrder 1
PIN -96 32 LEFT 8
PINATTR PinName RB
PINATTR SpiceOrder 2
PIN 96 32 RIGHT 8
PINATTR PinName TA
PINATTR SpiceOrder 3
PIN 96 0 RIGHT 8
PINATTR PinName TJ
PINATTR SpiceOrder 4
PIN 96 -32 RIGHT 8
PINATTR PinName TR
PINATTR SpiceOrder 5
