Version 4
SymbolType CELL
LINE Normal 23 23 -23 -23
LINE Normal -23 23 23 -23
RECTANGLE Normal -96 -64 96 64
CIRCLE Normal 32 32 -32 -32
WINDOW 0 0 -112 Center 2
WINDOW 3 0 -80 Center 2
WINDOW 39 -1 80 Center 2
SYMATTR Value gal20W12V
SYMATTR SpiceLine fd=0.1m fl=68m
SYMATTR Description Halogen Incandescent Lamp 12V 20W
SYMATTR Prefix X
SYMATTR SpiceModel gal20W12V
SYMATTR ModelFile ..\sym\ValVol\gal20W12V.lib
PIN -96 -32 LEFT 8
PINATTR PinName A
PINATTR SpiceOrder 1
PIN -96 32 LEFT 8
PINATTR PinName B
PINATTR SpiceOrder 2
PIN 96 32 RIGHT 8
PINATTR PinName TA
PINATTR SpiceOrder 3
PIN 96 -32 RIGHT 8
PINATTR PinName TF
PINATTR SpiceOrder 4
