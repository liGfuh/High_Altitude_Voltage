Version 4
SymbolType CELL
RECTANGLE Normal -96 -64 96 64
WINDOW 0 0 -112 Center 2
WINDOW 3 0 -80 Center 2
SYMATTR Value B57213P0121M3
SYMATTR Description NTC thermistor having a resistance of 120 ohms at 25oC
SYMATTR Prefix X
SYMATTR SpiceModel ..\sym\ValVol\Thermistors.lib
SYMATTR Value2 B57213P0121M3
PIN -96 -32 LEFT 8
PINATTR PinName RA
PINATTR SpiceOrder 1
PIN -96 32 LEFT 8
PINATTR PinName RB
PINATTR SpiceOrder 2
PIN 96 32 RIGHT 8
PINATTR PinName TA
PINATTR SpiceOrder 3
PIN 96 -32 RIGHT 8
PINATTR PinName TJ
PINATTR SpiceOrder 4
