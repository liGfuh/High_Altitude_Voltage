Version 4
SymbolType CELL
RECTANGLE Normal -96 64 96 -64
WINDOW 3 1 80 Center 2
WINDOW 0 0 -80 Center 2
SYMATTR Value STRL472
SYMATTR Prefix X
SYMATTR SpiceModel ..\sym\ValVol\ValVol.lib
SYMATTR Value2 STRL472
SYMATTR Description Quasi resonant flyback
PIN -64 -64 TOP 8
PINATTR PinName D
PINATTR SpiceOrder 1
PIN -64 64 BOTTOM 8
PINATTR PinName S
PINATTR SpiceOrder 2
PIN 64 64 BOTTOM 8
PINATTR PinName GND
PINATTR SpiceOrder 3
PIN 64 -64 TOP 8
PINATTR PinName VIN
PINATTR SpiceOrder 4
PIN 96 0 RIGHT 8
PINATTR PinName OCP/FB
PINATTR SpiceOrder 5
